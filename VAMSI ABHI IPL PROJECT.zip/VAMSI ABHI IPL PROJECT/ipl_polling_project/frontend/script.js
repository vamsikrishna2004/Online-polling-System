// Show different section when navbar button is clicked
function showSection(id) {
  const sections = document.querySelectorAll('main section');
  sections.forEach(section => section.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// Submit the poll form using fetch to backend
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("pollForm");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const data = {
      q1: form.q1.value,
      q2: form.q2.value,
      q3: form.q3.value,
      q4: form.q4.value,
      q5: form.q5.value,
      q6: form.q6.value,
    };

    fetch("http://localhost:5050/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error("Network error");
        }
        return response.text();
      })
      .then(msg => {
        alert("✅ Poll submitted successfully!\n\n" + msg);
        form.reset();
        showSection("home"); // Go back to home after submission
      })
      .catch(error => {
        alert("❌ Error submitting poll:\n" + error.message);
      });
  });
});
