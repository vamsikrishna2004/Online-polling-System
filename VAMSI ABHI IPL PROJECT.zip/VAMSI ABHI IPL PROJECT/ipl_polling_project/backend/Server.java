import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.sun.net.httpserver.*;

public class Server {
    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(5050), 0);
        server.createContext("/submit", new PollHandler());
        server.createContext("/responses", new ResponseHandler());
        server.createContext("/results", new ResultHandler());
        server.setExecutor(null);
        server.start();
        System.out.println("Server started on port 5050");
    }

    static class PollHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                InputStream is = exchange.getRequestBody();
                String body = new String(is.readAllBytes());

                try (Connection conn = DriverManager.getConnection("jdbc:sqlite:C:/Users/nakka/OneDrive/Desktop/VAMSI ABHI IPL PROJECT/ipl_polling_project/backend/polls.db")) {
                    String sql = "INSERT INTO responses (q1, q2, q3, q4, q5, q6) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    String[] values = body.replaceAll("[{}\"\\s]", "").split(",");

                    for (int i = 0; i < 6; i++) {
                        stmt.setString(i + 1, values[i].split(":")[1]);
                    }

                    stmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                String response = "Success";
                exchange.sendResponseHeaders(200, response.length());
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            } else {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            }
        }
    }

    static class ResponseHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
                return;
            }

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:polls.db");
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM responses")) {

                List<String> responseList = new ArrayList<>();
                while (rs.next()) {
                    String entry = String.format(
                        "{\"q1\":\"%s\",\"q2\":\"%s\",\"q3\":\"%s\",\"q4\":\"%s\",\"q5\":\"%s\",\"q6\":\"%s\"}",
                        rs.getString("q1"), rs.getString("q2"), rs.getString("q3"),
                        rs.getString("q4"), rs.getString("q5"), rs.getString("q6")
                    );
                    responseList.add(entry);
                }

                String jsonResponse = "[" + String.join(",", responseList) + "]";
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");

                byte[] responseBytes = jsonResponse.getBytes();
                exchange.sendResponseHeaders(200, responseBytes.length);
                OutputStream os = exchange.getResponseBody();
                os.write(responseBytes);
                os.close();

            } catch (SQLException e) {
                e.printStackTrace();
                exchange.sendResponseHeaders(500, -1); // Internal Server Error
            }
        }
    }

    static class ResultHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            StringBuilder html = new StringBuilder();
            html.append("<html><body><h1>Poll Results (Q1)</h1><ul>");

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:polls.db");
                 Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT q1, COUNT(*) as count FROM responses GROUP BY q1")) {

                while (rs.next()) {
                    String option = rs.getString("q1");
                    int count = rs.getInt("count");
                    html.append("<li>").append(option).append(": ").append(count).append("</li>");
                }

            } catch (SQLException e) {
                html.append("<p>Error: ").append(e.getMessage()).append("</p>");
            }

            html.append("</ul></body></html>");

            byte[] bytes = html.toString().getBytes("UTF-8");
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, bytes.length);
            OutputStream os = exchange.getResponseBody();
            os.write(bytes);
            os.close();
        }
    }
}
