import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.*;
import java.sql.*;
import java.util.stream.Collectors;
import org.json.JSONObject;

public class PollHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        if ("POST".equals(exchange.getRequestMethod())) {
            InputStreamReader isr = new InputStreamReader(exchange.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String requestBody = br.lines().collect(Collectors.joining());
            JSONObject json = new JSONObject(requestBody);

            try {
                Class.forName("org.sqlite.JDBC");
                System.out.println("✅ JDBC Driver Loaded.");
            } catch (ClassNotFoundException e) {
                System.out.println("❌ JDBC Driver NOT FOUND.");
                e.printStackTrace();
            }

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:polls.db")) {
                System.out.println("✅ Connected to DB.");
                System.out.println("Received: " + json.toString());

                String sql = "INSERT INTO responses (q1, q2, q3, q4, q5, q6) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, json.getString("q1"));
                pstmt.setString(2, json.getString("q2"));
                pstmt.setString(3, json.getString("q3"));
                pstmt.setString(4, json.getString("q4"));
                pstmt.setString(5, json.getString("q5"));
                pstmt.setString(6, json.getString("q6"));
                pstmt.executeUpdate();
                System.out.println("✅ Data inserted successfully!");
            } catch (SQLException e) {
                System.out.println("❌ SQL Error: " + e.getMessage());
                e.printStackTrace();
            }

            String response = "Success";
            exchange.sendResponseHeaders(200, response.length());
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }
}
